/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment4;

/**
 *
 * @author mpume
 */
public class Test {
    
  
    public static void main(String[] args) {
        
        
         MyLinkedList<Integer>list=new MyLinkedList<Integer>();
        
         //empty list
         System.out.println(list.toString());
         System.out.println("empty list:"+list.getMin());
           

           //when min is at first position
           list.append(new Integer(1));
           list.append(new Integer(4));
           list.append(new Integer(2));
           list.append(new Integer(3));
            
      System.out.println(list.toString());
      System.out.println("Test when min is at the first position: "+list.getMin());
      
      list.clear();
          
      //when min is at last position
       list.append(new Integer(4));
       list.append(new Integer(3));
       list.append(new Integer(6));
        list.append(new Integer(2));
            
      System.out.println(list.toString());
      System.out.println("Test when min is at the last position: "+list.getMin());
      list.clear();
       //when min is in the middle position
       list.append(new Integer(4));
       list.append(new Integer(3));
       list.append(new Integer(1));
       list.append(new Integer(6));
        list.append(new Integer(2));
            
      System.out.println(list.toString());
      System.out.println("Test when min is in the middle position: "+list.getMin());
      list.clear();
      
      //when min is at repeated
       list.append(new Integer(4));
       list.append(new Integer(4));
       list.append(new Integer(4));
        list.append(new Integer(4));
            
      System.out.println(list.toString());
      System.out.println("Test when min is repeated: "+list.getMin());
      
      
      
    }
    
    
    
}
