/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment5;

/**
 *
 * @author mpume
 */
public class StackAsMyLinkedList<E> {
    MyLinkedList<E> theStack;
    int size=0;
    public StackAsMyLinkedList()
    {
        theStack = new MyLinkedList<E>();
    }
    public void push(E newElement)
    {
        theStack.prepend(newElement);
         size=size+1;
      
    }
    public E pop()
    {
        E temp = null;
        boolean isDone = false;
        temp = theStack.getFirst();
        if (temp != null)
        {
            isDone = theStack.delete(temp);
             size=size-1;
         
        }
        if (isDone)
        {
            return temp;
        }else{
            return null;
        }
    }
    @Override
    public String toString()
    {
        return theStack.toString();
    }
    
      public E peek() {
       E top=theStack.getFirst();
       
       if(isEmpty()){
       
       return null;
       }
       return top;
    }
      
   public boolean isEmpty() {
      E top=theStack.getFirst();
        return top==null;
    }
    public int Size(){
   
   return size;}

      
}
