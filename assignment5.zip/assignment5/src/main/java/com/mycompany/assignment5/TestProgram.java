/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment5;

/**
 *
 * @author mpume
 */
public class TestProgram {
    
    
    public static void main(String args[]){
    
       
        StackAsMyLinkedList<Integer>stack= new  StackAsMyLinkedList<Integer>();
        QueueAsMyLinkedList<Integer>queue= new QueueAsMyLinkedList<Integer>();
        TaskManagementSystem object= new  TaskManagementSystem(); 
        
    //testing the empty method of stack when list is empty
    System.out.println("testing stack methods:");
       System.out.println("Empty:");
       System.out.println( stack.toString());
       System.out.println("Testing if object is empty: "+stack.isEmpty());
       System.out.println("Testing the peek class: "+stack.peek());
       System.out.println("Testing the size: "+stack.Size());
       
    //testing the method when the is an element
    System.out.println("\nwhen element is added:");
    stack.push(2);
    System.out.println( stack.toString());
    System.out.println("Testing if object is empty: "+stack.isEmpty());
    System.out.println("Testing the peek class: "+stack.peek());
    System.out.println("Testing the size: "+stack.Size());
    
    System.out.println("\nwhen more element is added:");
    stack.push(2);
    stack.push(4);
     stack.push(6);
      stack.push(10);
       stack.push(8);
     System.out.println( stack.toString());
    System.out.println("Testing if object is empty: "+stack.isEmpty());
    System.out.println("Testing the peek class: "+stack.peek());
    System.out.println("Testing the size: "+stack.Size()+"\n");
    //_______________________________________________________________
    System.out.println("testing queue methods:");
     //testing the empty method of queue when list is empty
       System.out.println("Empty:");
       System.out.println( queue.toString());
       System.out.println("Testing if object is empty: "+queue.isEmpty());
       System.out.println("Testing the peek class: "+queue.peek());
       System.out.println("Testing the size: "+queue.Size());
       
    //testing the method when the is an element
    System.out.println("\nwhen element is added:");
    queue.enqueue(2);
    System.out.println( queue.toString());
    System.out.println("Testing if object is empty: "+queue.isEmpty());
    System.out.println("Testing the peek class: "+queue.peek());
    System.out.println("Testing the size: "+queue.Size());
    
    System.out.println("\nwhen more element is added:");
    queue.enqueue(2);
    queue.enqueue(4);
    queue.enqueue(6);
     queue.enqueue(10);
     queue.enqueue(8);
     System.out.println(  queue.toString());
    System.out.println("Testing if object is empty: "+ queue.isEmpty());
    System.out.println("Testing the peek class: "+ queue.peek());
    System.out.println("Testing the size: "+ queue.Size()+"\n");
    
    //testing tast management when empty 
    System.out.println("testing tast management when empty");
   
    
    
     object.toString();
     object.process();
     object.undo();
     System.out.println("\ntesting tast management when adding a value");
   
     object.add(5);
     object.process();
     object.undo();
     System.out.println("\ntesting tast management when adding more value");
    
     object.add(5);
     object.add(2);
     object.add(3);
     object.process();
     object.undo();
    
    
    }
    
}
