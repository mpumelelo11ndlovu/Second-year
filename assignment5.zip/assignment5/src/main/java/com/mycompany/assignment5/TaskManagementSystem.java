/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment5;

/**
 *
 * @author mpume
 */
public class TaskManagementSystem<E> {
    StackAsMyLinkedList<E>stack= new  StackAsMyLinkedList<E>();
    QueueAsMyLinkedList<E>Queue= new  QueueAsMyLinkedList<E>();
    
    
    public void add(E item){
        
        
        
        Queue.enqueue(item);
        System.out.println("item "+item+ " has been added");
        
        
                  
        } 
    
    
    public void process(){
    
    
       if(Queue.isEmpty()){
        
        System.out.println("couldnt process the information");
        
        }
       else{
       
       E temp=Queue.dequeue();
       
       
       stack.push(temp);
         System.out.println("processed successfully ");
         
       
                     }
      
    }
    public void undo(){
      
        if(stack.isEmpty()){
        
        System.out.println("the is nothing to undo");
        
        
        }
        else{
        E temp=stack.pop();
      
      System.out.println(temp+" has been undone");
        }
      
      
      }
     
   
    
    
    
}
