/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment5;

/**
 *
 * @author mpume
 */
public class QueueAsMyLinkedList<E> {
    MyLinkedList<E> theQueue;
    int size = 0;
    public QueueAsMyLinkedList()
    {
        theQueue = new MyLinkedList<>();
    }
    public void enqueue(E newElement)
    {
        theQueue.append(newElement);
        size=size+1;
      
    }
    public E dequeue()
    {
        E temp = null;
        boolean isDone = false;
        temp = theQueue.getFirst();
        if (temp != null)
        {
            isDone = theQueue.delete(temp);
        size=size-1;
       
        }
        if (isDone)
        {
            return temp;
        }else{
            return null;
        }
    }
    @Override
    public String toString()
    {
        return theQueue.toString();
    }
    
    public E peek() {
       E top=theQueue.getFirst();
       
       if(isEmpty()){
       
       return null;
       }
       return top;
    }
      
   public boolean isEmpty() {
      E top=theQueue.getFirst();
        return top==null;
    }
   public int Size(){
   
   return size;}
}