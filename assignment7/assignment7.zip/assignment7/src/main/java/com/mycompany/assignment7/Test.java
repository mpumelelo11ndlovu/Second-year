/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignment7;

/**
 *
 * @author mpumelelo Ndlovu
 */
public class Test {

  
   public static void main(String[] args) {
        QueueAsMyLinkedList<Integer> list = new QueueAsMyLinkedList<>();

        list.enqueue(3);
        list.enqueue(5);
        list.enqueue(8);
        list.enqueue(7);
        list.enqueue(1);

        System.out.println("Unsorted List: " + list.toString());

        QueueAsMyLinkedList<Integer> sortedList = method(list, 5); 
        System.out.println("Sorted List : " + sortedList.toString());
    }

    // Recursive method to sort the queue in descending order
    public static QueueAsMyLinkedList<Integer> method(QueueAsMyLinkedList<Integer> queue, int x) {
        // Base case- if the queue is empty, return it
        if (x == 0) {
            return queue; 
        }

        //  Find and remove the largest element from the queue
        Integer largest = RemoveLargest(queue, x);

        //  Recursively sort the remaining queue
        QueueAsMyLinkedList<Integer> sortedQueue = method(queue, x - 1);

        //  Enqueue the largest element to the sorted queue
        sortedQueue.enqueue(largest);

        return sortedQueue;
    }

    // My Recursive method that finds and removes the largest element from the queue
    public static Integer RemoveLargest(QueueAsMyLinkedList<Integer> queue, int size) {
        if (size == 1) {
            return queue.dequeue(); 
        }

       
        Integer front = queue.dequeue();

       
        Integer largest = RemoveLargest(queue, size - 1);

        // Compare and keep track of the largest element
        if (front >= largest) {
            // Put the smaller element back in the queue and return the original largest
            queue.enqueue(largest);
            return front;
        } else {
            // Keep the largest, and enqueue the current front back into the queue
            queue.enqueue(front);
            return largest;
        }
    }
}


