/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment2;

/**
 *
 * @author mpume
 */
import java.util.*;

public class Test {

    public static void main(String args[]) {
       
        //Initialize arrays:O(1)**
        int arr_int[] = new int[5];
        double arr_double[] = new double[5];
        
        //Initialize Random:O(1)**
        Random rands = new Random();
        // Randomizing numbers for instances of storing in objects
        
         // Populate arrays with random numbers: O(n)**
        for (int x = 0; x < 5; x++) {
            arr_int[x] = rands.nextInt(1000);
            arr_double[x] = rands.nextDouble() * 1000;
        }

        // Ensure sold prices are greater than the cost, tax, and shipping price
       
        // Adjust sold prices: O(1)**
        double margin = 50.0; 
        arr_double[1] = arr_double[0] + rands.nextDouble() * (1000 - arr_double[0]) + margin;
        arr_double[3] = arr_double[0] + rands.nextDouble() * (1000 - arr_double[0]) + margin;

        // Adjust tax and shipping price to be within a reasonable range: O(1)**
        arr_double[2] = arr_double[2] * 0.1; // Tax should be less than or equal to 10% of cost
        arr_double[4] = arr_double[4] * 0.1; // Shipping price should be less than or equal to 10% of cost

        System.out.println("\n---------------Monthly Profit Calculator for Earpods-------------");

        // Extract values for Retail and Online objects: O(1)**
        
        double cost = arr_double[0];
        double soldPrice = arr_double[1];
        int quantity = arr_int[0];
        double tax = arr_double[2];

        // Object for retail
        Store retail = new Retail(cost, soldPrice, quantity, tax);

     
        double soldPrice2 = arr_double[3];
        int quantity2 = arr_int[1];
        double shipPrice = arr_double[4];

        // Object for online
        Store online = new Online(cost, soldPrice2, quantity2, shipPrice);
       
        // ArrayList for storing objects: O(1)
        // Array for objects and storing
        ArrayList<Store> arrayL = new ArrayList<>(2);
        
        // Add elements to ArrayList: O(n)
        arrayL.add(retail);
        arrayL.add(online);

        // Sorting according to the profit made
        
        // Sort ArrayList by profit: O(n log n)**
        arrayL.sort(new Comparator<Store>() {
            @Override
            public int compare(Store online, Store retial) {
                return Double.compare(online.Profit(), retail.Profit());
            }
        });
        // Print results using explicit call: O(n)
       
        System.out.println("Explicit call: ");
        for (Store p : arrayL) {
            
            System.out.println("\n"+p.toString());
            
        }
        
       // Print results using implicit call: O(n)
      System.out.println("\nImplicit call: ");
        for (Store p : arrayL) {
            
            System.out.println("\n"+p);
            
        }
       
        // Time complexity analysis
        System.out.println("\nTime Complexity Analysis for the Store(superclass) class");
        System.out.println("\nDetailed Method (t-notation):7tstore + 6tfetch + 4treturn + TgetCost() + TgetSoldPrice()+ TgetQuantity()");
        System.out.println("Simplified Method:20");
        System.out.println("Asymptotic Analysis (Big O Notation):O(1)");
        
        System.out.println("\nTime Complexity Analysis for the Online(subclass) class");
        System.out.println("\nDetailed Method (t-notation):6tstore + 5tfetch + 4treturn + 2TgetCost() + 2TgetSoldPrice()+ TgetQuantity()");
        System.out.println("t+ + t- + t* +Tprofit() + Tsuper()+ 8tCall + TgetShippingprice()");
        System.out.println("Simplified Method:34");
        System.out.println("Asymptotic Analysis (Big O Notation):O(1)");
        
        System.out.println("\nTime Complexity Analysis for the Retail(subclass) class");
        System.out.println("\nDetailed Method (t-notation):7tstore + 5tfetch + 3treturn + TgetCost() + 2TgetSoldPrice()+ TgetQuantity()");
        System.out.println("t+ + t- + t* +Tprofit() + Tsuper()+ 8tCall + TgetTax()");
        System.out.println("Simplified Method:33");
        System.out.println("Asymptotic Analysis (Big O Notation):O(1)");
        
        
        System.out.println("\nTime Complexity Analysis for the Test class");
        System.out.println("\nDetailed Method (t-notation):27tstore + 29tfetch +9t[.] + 12tfetch");
        System.out.println("2nt+ + 3nt< + 3t< + 4t* + 2t- + 12ntfetch +7ntstore ");
        System.out.println("Simplified Method:86+24n");
        System.out.println("Asymptotic Analysis (Big O Notation):O(n log n)");
        
        
    }
}