/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.rewind;

/**
 *
 * @author mpume
 */
import java.util.Scanner;
public class Test {
    
    
   public static void main(String args[]){
   
      
       Scanner scans=new Scanner(System.in);
       
       
   
        
     System.out.println("\n---------------monthly Profit calculator for earpods-------------");
        
     System.out.println("Store:");
     System.out.print("\nEnter the cost for the earpods : ");
     double cost=scans.nextDouble();
     
     
     System.out.print("\nEnter the sold price from the store: ");
     double soldPrice=scans.nextDouble();
     
     System.out.print("\nhow many of those items where bought from the store: ");
     int quantity=scans.nextInt();
     System.out.print("\nwhat is the tax rate per each item : ");
     double tax=scans.nextDouble();
       
     // object for retail
     Store retail=new Retail(cost,soldPrice,quantity,tax);
    
   
    
    System.out.println("\nOnline:");
   
     System.out.print("\nEnter the sold price from online : ");
     double soldPrice2=scans.nextDouble();
     
     System.out.print("\nhow many of those items where bought online: ");
     int quantity2=scans.nextInt();
     
     System.out.print("\nwhats the shipping price of the earpods: ");
     double shipPrice=scans.nextDouble();
      // object for Online
     Store online=new Online(cost,soldPrice2,quantity2,shipPrice);
    
    
     //Explicit call
     System.out.print("\nExplicit call\n");
     System.out.print("\n"+retail.toString());
     System.out.print("\n"+online.toString());
     
     //implicit Call
     System.out.print("\nImplicit call\n");
     System.out.print("\n"+retail);
     System.out.print("\n"+online);
     
     
     
    
   
 
   
   
      
   
   
   
   
   
   
   
   
   }
   
   
  
   
  
    
  
    
    
}
