/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.rewind;

/**
 *
 * @author mpume
 */
public class Online extends Store{
    
    
   private double shippingprice;
   
   
    public Online(){
    
    
    }
    
   public Online(double cost,double SoldPrice,int quantity,double shippingprice){
       
       super(cost,SoldPrice,quantity);
       
       this.shippingprice=shippingprice;
   
   }
   
  //mutator
  
   public void setShippingprice(double shippingprice){
   
   
     this.shippingprice=shippingprice;
   
   
   }
  
  
 //Accessor
   
   public double getShippingprice(){
   
   
       return shippingprice;
       
   }
   
   
   @Override
   public double Profit(){
   
    double profit=(getSoldPrice()-(getCost()+getShippingprice()))*getQuantity();
   
   return profit;
   
  }
  
  
    @Override
    
   public String toString(){
  
      String formatter=String.format("Online profit:\ncost:%.2f\tPricesold:%.2f\tProfit made:%.2f\n",getCost(),getSoldPrice(),Profit());
      
      return formatter;
  
  }
    
    
    
    
    
    
    
    
    
    
    
    
    
}