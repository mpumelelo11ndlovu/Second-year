/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.rewind;

/**
 *
 * @author mpume
 */
public class Retail extends Store {
    
    
    
 private double tax;
   
     public Retail(){
    
    
    }
   public Retail(double cost,double SoldPrice,int quantity,double tax){
       
       super(cost,SoldPrice,quantity);
       this.tax=tax;
   
   }
   
   //mutator
   
    public void setRetail(){
    
       this.tax=tax;
    
    
    
    }
   
  
   //Accessor
    
    public double getTax(){
    
    
    return tax;
    
    }
   
   @Override
   public double Profit(){
   
    double profit=(getSoldPrice()-(getCost()+getTax()))*getQuantity();
   
   return profit;
   
  }
   
  
 
  
  
   @Override
   public String toString(){
  
      String formatter=String.format("Retail Profit:\ncost:%.2f\tPricesold:%.2f\tProfit made:%.2f",getCost(),getSoldPrice(),Profit());
      
      return formatter;
  
  }
 
    
}
