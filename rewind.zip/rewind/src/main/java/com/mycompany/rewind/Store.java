/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.rewind;

/**
 *
 * @author mpume
 */
abstract public class Store {
    
   private double cost;
   private double SoldPrice;
   private int quantity;
   
   //Constructors
    public Store(){
    
    
    }
   public Store(double cost,double SoldPrice,int quantity){
   
     this.cost=cost;
      this.SoldPrice=SoldPrice;
      this.quantity=quantity;
     
   
   }
  //abstract class
  
   abstract public double Profit();
   
 //mutators

  public void setCost(double cost){
  
       this.cost=cost;
  
  }
  public void setSoldPrice(double SoldPrice){
  
      this.SoldPrice=SoldPrice;
 }
  
 public void setQuantity(int quantity){
  
     this.quantity=quantity;
 }
  
//Accessors
  public double getCost(){
  
  return cost;
  
  }
  
  public double getSoldPrice(){
  
    return SoldPrice;
  
 } 
 public int getQuantity(){
  
    return quantity;
  
 } 
  

   @Override
   
  public String toString(){
  
     String formatter=String.format("Store profit:\ncost:%.2f\tPricesold:%.2f\tquantity:%d",getCost(),getSoldPrice(),getQuantity());
      
      
      return formatter;
  
  }
     
}