/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignment6;

/**
 *
 * @author mpume
 */ import java.util.*;
public class Test {

    public static void main(String[] args) {
     MyLinkedList<Integer> list = new MyLinkedList<>();
    Scanner scans = new Scanner(System.in);

    
    while (true) {
      System.out.print("Enter a number (a negative number to STOP): ");
      int answer = scans.nextInt();
      if (answer < 0){
          
         break; }
      
        list.append(answer);
    }

   
    System.out.println("Question List = " + list.toString());

  
    MyLinkedList<Integer> multipliedList = list.Multiply();

   
    System.out.println("Answer List = " + multipliedList.toString());

   
  }
    }

