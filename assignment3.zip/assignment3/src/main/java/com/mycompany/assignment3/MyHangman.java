/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment3;

/**
 *
 * @author mpume
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class MyHangman {

    public static int MAX_GUESSES = 7;
    public static MyArrayListHM<String> words = new MyArrayListHM<>();
    public static MyArrayListHM<Character> secretWord = new MyArrayListHM<>();
    public static MyArrayListHM<Character> guessedWord = new MyArrayListHM<>();
   

    public static void main(String[] args) {
        loadWords();
        startNewGame();
        playGame();
    }

    public static void loadWords() {
        try {
            FileReader file = new FileReader("words.txt");
            Scanner scans = new Scanner(file);
            int i = 0;

            while (scans.hasNext()) {
                String line = scans.nextLine();
                words.add(i, line);
                i++;
            }

            System.out.println("The words: " + words.toString());
            words.sortList();
            System.out.println("The sorted words: " + words.toString());

            file.close();
        } catch (IOException e) {
            System.out.print("Could not read from file: " + e.getMessage());
        }
    }

    public static void startNewGame() {
       // Select a random word
        Random rand = new Random();
        int randomize = rand.nextInt(words.getSize());
        String name = words.get(randomize).toUpperCase();

        int y = 0;
        
        for (char temp : name.toCharArray()) {
            secretWord.add(y, temp);
            guessedWord.add(y, '_');
            y++;
        }
    // Reset the number of guesses allowed
        MAX_GUESSES = 7;
    }

    public static void playGame() {
        System.out.println("Welcome to Hangman!\n");
        System.out.println("Guessed word: "+guessedWord.toString());
        Scanner scan = new Scanner(System.in);
     // Continue the game until the user has no guesses left
        while (MAX_GUESSES > 0) {
            System.out.print("Enter a letter: ");
            String answer = scan.nextLine().toUpperCase();
       // Check if the guessed letter is in the secret word
            if (secretWord.contains(answer.charAt(0))) {
                System.out.println("Correct guess!");
                updateGuessedWord(answer.charAt(0));
                System.out.println("Guessed word: "+guessedWord.toString());
       // Decrement guesses and check if the user has lost               
            } else {
                MAX_GUESSES--;
                if (MAX_GUESSES == 0) {
                    System.out.println("You lose!");
                } else {
                    System.out.println( " guesses left: "+MAX_GUESSES);
                }
            }
      // Check if the word has been fully guessed
            if (isWordGuessed()) {
                System.out.println("Congratulations! You guessed the word: " + secretWord.toString());
                break;
            }
        }
    }
  // Update the guessedWord list with the correctly guessed letter
    public static void updateGuessedWord(char answer) {
        for (int x = 0; x < secretWord.getSize(); x++) {
            if (secretWord.get(x) == answer) {
                guessedWord.remove(x);
                guessedWord.add(x, answer);
            }
        }
    }

    public static boolean isWordGuessed() {
        return !guessedWord.contains('_');
    }
}